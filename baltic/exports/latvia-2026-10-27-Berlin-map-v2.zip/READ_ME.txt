LATVIA TRAIN REPORTS - CORRECTED MAP CSV (v2)

File: latvia-2026-10-27-Berlin-map-v2.csv
Berlin calendar date: 2026-10-27
Rows: 1,486,429

This version only removes columns. All original rows, their order and every
selected value are unchanged. It supersedes the earlier -map.csv export, which
removed stationary reports and changed timestamp formatting and global order.

Columns:
received_at_utc: receipt time, UTC. Use this for playback chronology.
source_time_utc: Vivi map-updater time, not a verified GPS-fix timestamp.
service_date: original source service date, preserved across midnight.
train_id: original internal service ID; keep as text.
route_label: public train/service number; keep as text.
latitude, longitude: original provider coordinates and precision.
is_gps_active: provider assertion True / False; blank would mean unknown.

Group tracks by (service_date, train_id), label with route_label. Do not connect
successive CSV rows without grouping: different trains are interleaved.
Times retain the original ISO 8601 format, including six fractional digits and
+00:00. File dates use Berlin calendar days, so some UTC dates differ from the
filename. Source timestamps may repeat or move backward; they are not replaced
with invented values. Import timestamps as timezone-aware UTC values and IDs
as text. This CSV has no derived segment_start field.

There are 66 per-service receipt gaps over 15 seconds, exactly as in the
original file. No gap has been filled or introduced by this export. Repeated
positions and their new timestamps are retained. Coordinates are not rounded,
snapped to tracks or interpolated. GPS-inactive reports are retained.

Verified every selected cell in all rows against the original, in order.
Both datetime columns also parsed successfully in pandas 2.2.3.
CSV SHA-256: 0c18e61b8eea17bebc27e68f38d4243ec0e67670a4f5aae668dc0fd0caba806b

Source: public Vivi map stream, wss://trainmap.pv.lv/ws.
The code licence does not establish redistribution rights for live-feed data.
