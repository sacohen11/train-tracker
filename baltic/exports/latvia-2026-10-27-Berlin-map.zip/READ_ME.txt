Latvia map data, 26-27 October 2026

Each ZIP contains one ordinary UTF-8 CSV. File dates use the Berlin calendar.
All timestamps inside the CSV use UTC. The 26 October capture starts at 09:05
UTC (10:05 Berlin) after a feed outage; missing history is not reconstructed.

Columns:
service_id: country + source + original service date + internal service ID.
  This identifies a service instance, not a physical trainset.
train_number: the Vivi map's public train/service number, kept as text.
received_at_utc: when our recorder received this actual report.
source_time_utc: Vivi map-updater time, NOT a verified onboard GPS-fix time.
latitude, longitude: provider position, with the original saved precision.
is_gps_active: true/false is Vivi's assertion; blank means unknown.
segment_start: 1 starts a new path segment for that service; 0 continues it.

To draw paths, group by service_id and sort by received_at_utc. Split before
each row with segment_start=1. Do not connect the new segment to the old one.
Use train_number for labels and is_gps_active to style or filter positions.
Both provider GPS-active and GPS-inactive positions are retained.

Consecutive reports at the same position and with the same quality/label are
reduced to the first and last original reports in that run. Every coordinate
change is retained, together with the beginning and end of stops. No rounding,
interpolation, track snapping, or invented one-second GPS fixes are used.
Intermediate repeated reports and their individual timestamps are omitted.

Segments break at gaps greater than 15 seconds in the ORIGINAL consecutive
receipt or source times, time regressions, quality changes, missing-source-time
transitions, invalid coordinates, and file boundaries. Use segment_start:
a long interval between identical retained positions can be a continuous stop,
not an outage. Do not reapply a 15-second gap rule to the compact CSV itself.

The complete 38-column recordings remain in the original exports. Raw-report
counts and retained map-point counts are different. Source: the public Vivi
map stream, wss://trainmap.pv.lv/ws. Repository code licensing does not grant
rights to provider data; the live-feed redistribution terms are unverified.
